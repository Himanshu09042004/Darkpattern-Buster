import requests
from bs4 import BeautifulSoup
import time
import pandas as pd

max_retries = 3  # Move max_retries to a higher scope

def get_website_content(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        'Referer': 'https://www.google.com/'  # You can add a referer header
    }

    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=10)  # Adjust timeout as needed
            response.raise_for_status()  # Raise an HTTPError for bad responses (4xx and 5xx)
            return response.text
        except requests.exceptions.RequestException as e:
            print(f"Attempt {attempt + 1} failed for {url}. Error: {e}")
            time.sleep(2)  # Wait for 2 seconds before retrying

    print(f"Maximum retries reached. Unable to fetch content from {url}.")
    return None

def detect_dark_patterns(html_content, url):
    warnings = []  # List to store warnings

    print(f"Analyzing {url}")
    soup = BeautifulSoup(html_content, 'html.parser')
 
    dark_patterns = [
        ('hidden elements', lambda tag: tag.get('style') and 'hidden' in tag.get('style', '').lower()),
        ('misleading subscription text', lambda tag: tag.name == 'div' and 'subscribe' in tag.get_text().lower()),
        ('forced subscription form', lambda tag: tag.name == 'form' and tag.get('action') == '/subscribe'),
        ('fake buttons', lambda tag: tag.name == 'div' and 'button' in tag.get('class', []) and 'click' in tag.get_text().lower()),
        ('misleading links', lambda tag: tag.name == 'a' and 'click' in tag.get('href', '').lower()),
        ('pop-ups', lambda tag: tag.has_attr('onclick')),
        ('hidden charges', lambda tag: 'hidden charges' in tag.get_text().lower()),
        ('pre-checked boxes', lambda tag: tag.name == 'input' and tag.get('type') == 'checkbox' and tag.has_attr('checked')),
        ('scarcity tactics', lambda tag: 'scarcity' in tag.get_text().lower()),
        ('misleading urgency', lambda tag: 'urgency' in tag.get_text().lower()),
        ('social proof manipulation', lambda tag: 'social proof' in tag.get_text().lower()),
        ('hidden subscription auto-renewals', lambda tag: 'auto-renew' in tag.get_text().lower()),
        ('tricky navigation', lambda tag: 'tricky navigation' in tag.get_text().lower()),
        ('hidden opt-outs', lambda tag: 'hidden opt-out' in tag.get_text().lower()),
        ('misleading error messages', lambda tag: 'misleading error' in tag.get_text().lower()),
        ('bait-and-switch tactics', lambda tag: 'bait-and-switch' in tag.get_text().lower()),
        ('false limited-time offers', lambda tag: 'false limited-time offers' in tag.get_text().lower()),
        ('misdirection', lambda tag: 'misdirection' in tag.get_text().lower()),
        ('hidden terms and conditions', lambda tag: 'hidden terms' in tag.get_text().lower()),
        ('fake reviews/testimonials', lambda tag: 'fake reviews' in tag.get_text().lower()),
        ('unwanted add-ons', lambda tag: 'unwanted add-ons' in tag.get_text().lower()),
        ('misleading discounts', lambda tag: 'misleading discounts' in tag.get_text().lower()),
        ('phantom products', lambda tag: tag.get('class') and 'product' in tag.get('class')),
        ('fake scarcity counters', lambda tag: 'limited stock' in tag.get_text().lower() or 'countdown' in tag.get_text().lower()),
        ('forced continuity', lambda tag: 'continuity' in tag.get_text().lower()),
        ('hidden unsubscribe options', lambda tag: 'unsubscribe' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading upsells', lambda tag: 'upsell' in tag.get_text().lower()),
        ('hidden fees', lambda tag: 'fee' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('phantom discounts', lambda tag: 'discount' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('dark patterns in CAPTCHA', lambda tag: 'captcha' in tag.get_text().lower()),
        ('hidden unsubscribe button', lambda tag: tag.name == 'button' and 'unsubscribe' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('forced account creation for purchase', lambda tag: 'create account' in tag.get_text().lower() and 'purchase' in tag.get_text().lower()),
        ('deceptive email opt-ins', lambda tag: 'email opt-in' in tag.get_text().lower() and 'deceptive' in tag.get_text().lower()),
        ('misleading search results', lambda tag: 'search results' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('dark patterns in notifications', lambda tag: 'notification' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('hidden unsubscribe link in email', lambda tag: 'unsubscribe' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('forced data sharing', lambda tag: 'data sharing' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('fake chatbots', lambda tag: 'chatbot' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('trick to extend subscription automatically', lambda tag: 'extend' in tag.get_text().lower() and 'auto' in tag.get_text().lower() and 'subscription' in tag.get_text().lower()),
        ('hidden unsubscribe link', lambda tag: 'unsubscribe' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('forced newsletter sign-up', lambda tag: 'newsletter' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('fake error messages', lambda tag: 'error' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('misleading personalization', lambda tag: 'personalized' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('hidden price until checkout', lambda tag: 'price' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower() and 'checkout' in tag.get_text().lower()),
        ('misleading testimonials', lambda tag: 'testimonial' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced social sharing', lambda tag: 'social sharing' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('phantom payments', lambda tag: 'payment' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('fake security badges', lambda tag: 'security' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('forced app download', lambda tag: 'download' in tag.get_text().lower() and 'app' in tag.get_text().lower()),
        ('dark patterns in surveys', lambda tag: 'survey' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake countdown timers', lambda tag: 'countdown' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden terms on checkout', lambda tag: 'terms' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower() and 'checkout' in tag.get_text().lower()),
        ('misleading shipping information', lambda tag: 'shipping' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced location sharing', lambda tag: 'location' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in newsletters', lambda tag: 'newsletter' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake progress bars', lambda tag: 'progress' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden unsubscribe on confirmation page', lambda tag: 'unsubscribe' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower() and 'confirmation' in tag.get_text().lower()),
        ('forced sharing on social media', lambda tag: 'social media' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in terms of service', lambda tag: 'terms of service' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake trust seals', lambda tag: 'trust' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('misleading product labeling', lambda tag: 'product labeling' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced email subscriptions', lambda tag: 'email subscription' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in account settings', lambda tag: 'account settings' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake endorsements', lambda tag: 'endorsements' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden cancellation policies', lambda tag: 'cancellation policies' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading delivery times', lambda tag: 'delivery times' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced email verifications', lambda tag: 'email verification' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in confirmation emails', lambda tag: 'confirmation email' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake price reductions', lambda tag: 'price reductions' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden membership fees', lambda tag: 'membership fees' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading warranties', lambda tag: 'warranties' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced email notifications', lambda tag: 'email notification' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in account deletion', lambda tag: 'account deletion' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake customer service', lambda tag: 'customer service' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden subscription terms', lambda tag: 'subscription terms' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading user agreements', lambda tag: 'user agreements' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced updates', lambda tag: 'update' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in password creation', lambda tag: 'password creation' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake discounts based on location', lambda tag: 'discounts' in tag.get_text().lower() and 'location' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden product limitations', lambda tag: 'product limitations' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading privacy policies', lambda tag: 'privacy policies' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced guest checkouts', lambda tag: 'guest checkout' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in profile settings', lambda tag: 'profile settings' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake testimonials from influencers', lambda tag: 'testimonials' in tag.get_text().lower() and 'influencers' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden inactivity fees', lambda tag: 'inactivity fees' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading checkout progress indicators', lambda tag: 'checkout progress' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced account linking', lambda tag: 'account linking' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in user reviews', lambda tag: 'user reviews' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake product bundles', lambda tag: 'product bundles' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden minimum purchase requirements', lambda tag: 'minimum purchase requirements' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading product ratings', lambda tag: 'product ratings' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced email newsletters', lambda tag: 'email newsletter' in tag.get_text().lower() and 'forced' in tag.get_text().lower()),
        ('dark patterns in returns policy', lambda tag: 'returns policy' in tag.get_text().lower() and 'dark pattern' in tag.get_text().lower()),
        ('fake awards or certifications', lambda tag: 'awards' in tag.get_text().lower() and 'certifications' in tag.get_text().lower() and 'fake' in tag.get_text().lower()),
        ('hidden terms in email footers', lambda tag: 'email footers' in tag.get_text().lower() and 'hidden' in tag.get('style', '').lower()),
        ('misleading account upgrade benefits', lambda tag: 'account upgrade benefits' in tag.get_text().lower() and 'misleading' in tag.get_text().lower()),
        ('forced data retention', lambda tag: 'data retention' in tag.get_text().lower() and 'forced' in tag.get_text().lower())
    ]

    for pattern_name, pattern_func in dark_patterns:
        if soup.find_all(pattern_func):
            warnings.append(f"{pattern_name.capitalize()} detected!")

    return warnings

def main():
    excel_file_path = "H:\python\Book1.xlsx"
    df = pd.read_excel(excel_file_path, sheet_name='Book1', engine='openpyxl')

    for url in df['url name']:  # Iterate over the 'url name' column in the DataFrame
        website_content = get_website_content(url)

        if website_content:
            warnings = detect_dark_patterns(website_content, url)

            if warnings:
                print(f"Warnings for {url}:")
                for warning in warnings:
                    print(f" - {warning}")
            else:
                print(f"No dark patterns found on {url}")
        else:
            print(f"Unable to analyze the website at {url}. Check the URL and try again.")

if __name__ == "__main__":
    main()
